```python
import math
import matplotlib.pyplot as plt
import numpy as np
from pandas_datareader import data
tru = data.DataReader('TRU', 'yahoo',start='1/1/2009')
tru.head()
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>High</th>
      <th>Low</th>
      <th>Open</th>
      <th>Close</th>
      <th>Volume</th>
      <th>Adj Close</th>
    </tr>
    <tr>
      <th>Date</th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>2015-06-25</th>
      <td>25.750000</td>
      <td>24.51</td>
      <td>24.620001</td>
      <td>25.400000</td>
      <td>25922300.0</td>
      <td>25.125340</td>
    </tr>
    <tr>
      <th>2015-06-26</th>
      <td>25.889999</td>
      <td>24.75</td>
      <td>25.490000</td>
      <td>24.850000</td>
      <td>3807900.0</td>
      <td>24.581289</td>
    </tr>
    <tr>
      <th>2015-06-29</th>
      <td>24.940001</td>
      <td>23.42</td>
      <td>24.010000</td>
      <td>24.370001</td>
      <td>1871200.0</td>
      <td>24.106478</td>
    </tr>
    <tr>
      <th>2015-06-30</th>
      <td>25.740000</td>
      <td>24.50</td>
      <td>24.850000</td>
      <td>25.100000</td>
      <td>840800.0</td>
      <td>24.828587</td>
    </tr>
    <tr>
      <th>2015-07-01</th>
      <td>25.299999</td>
      <td>24.52</td>
      <td>25.010000</td>
      <td>24.950001</td>
      <td>780000.0</td>
      <td>24.680208</td>
    </tr>
  </tbody>
</table>
</div>




```python
#Next, we calculate the number of days that have elapsed in our chosen time window
time_elapsed = (tru.index[-1] - tru.index[0]).days
```


```python
#Current price / first record (e.g. price at beginning of 2009) provides us with the total growth %
total_growth = (tru['Adj Close'][-1] / tru['Adj Close'][1])

#Next, we want to annualize this percentage
#First, we convert our time elapsed to the # of years elapsed
number_of_years = time_elapsed / 365.0
#Second, we can raise the total growth to the inverse of the # of years
#(e.g. ~1/10 at time of writing) to annualize our growth rate
cagr = total_growth ** (1/number_of_years) - 1

#Now that we have the mean annual growth rate above,
#we'll also need to calculate the standard deviation of the
#daily price changes
std_dev = tru['Adj Close'].pct_change().std()

#Next, because there are roughy ~252 trading days in a year,
#we'll need to scale this by an annualization factor
#reference: https://www.fool.com/knowledge-center/how-to-calculate-annualized-volatility.aspx

number_of_trading_days = 252
std_dev = std_dev * math.sqrt(number_of_trading_days)

#From here, we have our two inputs needed to generate random
#values in our simulation
print ("cagr (mean returns) : ", str(round(cagr,4)))
print ("std_dev (standard deviation of return : )", str(round(std_dev,4)))
```

    cagr (mean returns) :  0.2685
    std_dev (standard deviation of return : ) 0.3084
    


```python
#Generate random values for 1 year's worth of trading (252 days),
#using numpy and assuming a normal distribution
daily_return_percentages = np.random.normal(cagr/number_of_trading_days, std_dev/math.sqrt(number_of_trading_days), number_of_trading_days)+1

```


```python
#Now that we have created a random series of future
#daily return %s, we can simply apply these forward-looking
#to our last stock price in the window, effectively carrying forward
#a price prediction for the next year
#This distribution is known as a 'random walk'

price_series = [tru['Adj Close'][-1]]

for j in daily_return_percentages:
    price_series.append(price_series[-1] * j)

#Great, now we can plot of single 'random walk' of stock prices
plt.plot(price_series)
plt.show()
```


![png](output_4_0.png)



```python
#Now that we've created a single random walk above,
#we can simulate this process over a large sample size to
#get a better sense of the true expected distribution
number_of_trials = 3000

#set up an additional array to collect all possible
#closing prices in last day of window.
#We can toss this into a histogram
#to get a clearer sense of possible outcomes
closing_prices = []

for i in range(number_of_trials):
    #calculate randomized return percentages following our normal distribution
    #and using the mean / std dev we calculated above
    daily_return_percentages = np.random.normal(cagr/number_of_trading_days, std_dev/math.sqrt(number_of_trading_days),number_of_trading_days)+1
    price_series = [tru['Adj Close'][-1]]

    for j in daily_return_percentages:
        #extrapolate price out for next year
        price_series.append(price_series[-1] * j)

    #append closing prices in last day of window for histogram
    closing_prices.append(price_series[-1])

    #plot all random walks
    plt.plot(price_series)



plt.show()

#plot histogram
plt.hist(closing_prices,bins=40)

plt.show()
```


![png](output_5_0.png)



![png](output_5_1.png)



```python
#from here, we can check the mean of all ending prices
#allowing us to arrive at the most probable ending point
mean_end_price = round(np.mean(closing_prices),2)
print("Expected price: ", str(mean_end_price))
```

    Expected price:  123.52
    


```python
#lastly, we can split the distribution into percentiles
#to help us gauge risk vs. reward

#Pull top 10% of possible outcomes
top_ten = np.percentile(closing_prices,100-10)

#Pull bottom 10% of possible outcomes
bottom_ten = np.percentile(closing_prices,10);

#create histogram again
plt.hist(closing_prices,bins=40)
#append w/ top 10% line
plt.axvline(top_ten,color='r',linestyle='dashed',linewidth=2)
#append w/ bottom 10% line
plt.axvline(bottom_ten,color='r',linestyle='dashed',linewidth=2)
#append with current price
plt.axvline(tru['Adj Close'][-1],color='g', linestyle='dashed',linewidth=2)

plt.show()
```


![png](output_7_0.png)

